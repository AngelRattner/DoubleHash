﻿using System;

namespace DHashHW
{
    class Program
    {
        static void Main(string[] args)
        {
            Hash_DoubleHashing<int, int> hashT = new Hash_DoubleHashing<int, int>(2);
            
            hashT.Add(1, 7);
            hashT.Add(2, 5);
            hashT.Add(3, 5);
            hashT.Add(4, 8);
            hashT.Add(5, 36);
            hashT.Add(6, 5);
            hashT.Add(7, 1);
            hashT.Add(8, 4);
            int temp;
            hashT.GetValue(2,out temp);
            int temp2;
            hashT.Delete(2, out temp2);
            int temp3;
            hashT.GetValue(2, out temp3);
        }
    }
}
