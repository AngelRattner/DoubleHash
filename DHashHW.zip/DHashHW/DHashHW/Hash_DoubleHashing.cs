﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DHashHW
{
    class Hash_DoubleHashing<TKey, TValue>
    {
        //Single Cell Status:
        // Empty - data will be null 
        // Deleted - for existing data (data not null) where isDeleted is true
        // Occupied - for existing data (data not null) where isDeleted is false
        Data[] arr;
        const double M = 1.35; //extra 35% space
        int items;
        int maxItems;

        public Hash_DoubleHashing()
            : this(1024)
        { }

        public Hash_DoubleHashing(int maxItems)
        {
            //Add 35 percent more to the size of the array relative to the maximum expected items
            //size must be prime number
            int size = FindClosestPrimeNumber((int)(M * maxItems));

            arr = new Data[size];
            this.maxItems = maxItems;
        }
        private int FindClosestPrimeNumber(int size)
        {
            while (!IsPrimeNumer(size)) { size++; } return size;
        }
        private bool IsPrimeNumer(int size)
        {
            int sizeArr = (int)Math.Sqrt(size);
            for (int i = 2; i <= sizeArr; i++)
            {
                if (size % i == 0) return false;

            }
            return true;
        }

        public bool GetValue(TKey keyToFind, out TValue value)
        {
            int index = CalcHashCode(keyToFind);
            //# caclulate the index for the given key
            if (arr[index] == null || arr[index].isDeleted)
            {
                value = default;
                return false;
            }
            //# if the cell is empty no such item
            while (!arr[index].key.Equals(keyToFind))
            {
                index += StepHash(keyToFind, arr.Length);
                if (arr[index].isDeleted==true)
                {
                    value = default;
                    return false;
                }
            }
            //# if the cell is occupied by different key -> calculate step and loop till you find the match(this is your item) or empty cell(no such item)
            value = arr[index].val;
            return true;







            // note that the loop is circular 
        }

        public void Add(TKey key, TValue value)
        {
            int index = CalcHashCode(key);
            //# caclulate the index to put a value into
            if (arr[index]==null || !arr[index].isDeleted)
            {
                arr[index] = new Data(key, value);
            }
            //# if the cell is empty or deleted - insert into it
            else
            {
                while (arr[index] != null)
                {
                    index += StepHash(key, arr.Length);
                }
                arr[index] = new Data(key, value);
            }
            //# if not, calculate step and loop till the cell isempty or deleted 
            //# note that the loop is circular
            items++;
            //# increment the items count
            if (items>=maxItems)
            {
                ReHash();
            }
            //# If the number of added items exceeds the maximum capacity - Rehash
        }
        int StepHash(TKey k, int size)
        {
            string s = k.ToString();
            int step = (Convert.ToInt32(s[0]) + Convert.ToInt32(s[s.Length - 1])) % size;
            if (step == 0) return 1;
            return step;
        }

        public bool Delete(TKey keyToDelete, out TValue value)
        {
            int index = CalcHashCode(keyToDelete);
            //# caclulate the index for the given key
            if (arr[index]==null)
            {
                value = default;
                return false;
            }
            //# if the cell is empty no such item
            while (!arr[index].key.Equals(keyToDelete))
            {
                index +=  StepHash(keyToDelete, arr.Length);
            }
            //# if the cell is occupied by different key -> calculate step and loop till you find the match(this is your item) or empty cell(no such item)
            if (!arr[index].isDeleted)
            {
                value = arr[index].val;
                arr[index].isDeleted = true;
                return true;
            }


            //# If the key is found - mark the cell as deleted and save its value 

            //# note that the loop is circular
            value = default;
            return false;
        }

        private void ReHash()
        {
            items = 0;
            int size = arr.Length;
            int tempSize = size * 2;
            Data[] tempArr = new Data[FindClosestPrimeNumber(tempSize)];
            //# double the size of array and find the closest prime value to new size
            maxItems = maxItems * 2;
            //# double the maxItems'
            Data[] todeleteArr = arr;
            arr = tempArr;
            for (int i = 0; i < todeleteArr.Length; i++)
            {
                if (todeleteArr[i]!=null)
                {
                    this.Add(todeleteArr[i].key, todeleteArr[i].val);
                }
                
            }
            //# realocate all the existed items
        }

        private int CalcHashCode(TKey key)
        {
            int res = key.GetHashCode();
            return res % arr.Length; // index: 0 - len-1           
        }

        class Data 
        {
            public TKey key;
            public TValue val;
            public bool isDeleted;


            public Data(TKey key, TValue val)
            {
                this.key = key;
                this.val = val;
                this.isDeleted = false;
            }
        }

    }
}
